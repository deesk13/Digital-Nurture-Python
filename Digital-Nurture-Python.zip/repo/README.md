# Digital Nurture – Python & SQL Solutions

Solutions for the **Digital Nurture** upskilling program by **Aadithya R**  
B.Tech – Artificial Intelligence and Machine Learning, Saveetha Engineering College

---

## Repository Structure

```
Digital-Nurture-Python/
├── python/
│   ├── task_01_to_30/      # Python fundamentals (Tasks 1–30)
│   └── task_31_to_55/      # Advanced Python & real-world apps (Tasks 31–55)
├── mysql/
│   ├── schema.sql          # Event Management Database schema
│   └── solutions.sql       # All 25 SQL query solutions
├── data/
│   ├── employees.csv       # Sample employee data
│   ├── expenses.csv        # Sample expense data
│   └── sales.txt           # Sample sales data
└── README.md
```

---

## Module 1 – ANSI SQL Using MySQL

25 SQL exercises on an **Event Management Database** with 6 tables:
`users`, `events`, `sessions`, `registrations`, `feedback`, `resources`

| Range | Topics |
|-------|--------|
| 1–5   | JOINs, Aggregation, GROUP BY |
| 6–10  | HAVING, Subqueries, LEFT JOIN |
| 11–15 | Date Functions, CTEs, Time Conflicts |
| 16–20 | Window Functions (RANK), NOT IN, Correlated Subqueries |
| 21–25 | Trends, Duplicates, Duration Calculations |

**Files:** [`mysql/schema.sql`](mysql/schema.sql) · [`mysql/solutions.sql`](mysql/solutions.sql)

---

## Module 2 – Python 3 Programming (55 Tasks)

### Tasks 1–30 · Fundamentals

| Task | File | Topic |
|------|------|-------|
| 1 | `task_01_hello_world.py` | Hello World |
| 4 | `task_04_float_precision.py` | Float Precision – Net Salary |
| 5 | `task_05_multiple_assignments.py` | Multiple Assignment / Unpacking |
| 6 | `task_06_modulo.py` | Modulo Operator (Even/Odd) |
| 7 | `task_07_floor_division.py` | Floor Division – Bill Splitting |
| 8 | `task_08_min_max.py` | Min/Max Functions |
| 9 | `task_09_basic_input.py` | Basic Input / Greeting |
| 10 | `task_10_numeric_input.py` | Numeric Input – Age |
| 11 | `task_11_float_input.py` | Float Input – kg to lbs |
| 12 | `task_12_simple_if.py` | Simple If – Pass/Fail |
| 13 | `task_13_if_else.py` | If-Else – Even/Odd |
| 14 | `task_14_if_elif_else.py` | If-Elif-Else – Grade |
| 15 | `task_15_nested_if.py` | Nested If – Login Validation |
| 16 | `task_16_basic_for.py` | For Loop – 1 to 5 |
| 17 | `task_17_while_loop.py` | While Loop – Countdown |
| 18 | `task_18_break.py` | Break – First Even Number |
| 19 | `task_19_continue.py` | Continue – Sum of Odds |
| 20 | `task_20_pass.py` | Pass Statement |
| 21 | `task_21_indentation.py` | Consistent Indentation |
| 22 | `task_22_comments.py` | Comment Usage |
| 23 | `task_23_import_standard.py` | Import math – Circle Area |
| 24 | `task_24_all_import.py` | `from math import *` |
| 25 | `task_25_parameters.py` | Function Parameters – Add |
| 26 | `task_26_multiple_params.py` | Multiple Params – Rectangle Area |
| 27 | `task_27_len_function.py` | `len()` Function |
| 28 | `task_28_write_to_file.py` | Write to File |
| 29 | `task_29_read_from_file.py` | Read from File |
| 30 | `task_30_try_except.py` | Try-Except – Division |

> **Note:** Tasks 2 (Jupyter Notebook) and 3 (VS Code Setup) are environment setup tasks without standalone `.py` files.

### Tasks 31–55 · Advanced Python & Real-World Applications

| Task | File | Topic |
|------|------|-------|
| 31 | `task_31_create_list.py` | Create List – Shopping Cart |
| 32 | `task_32_append_to_list.py` | Append to List |
| 33 | `task_33_update_dictionary.py` | Update Dictionary |
| 34 | `task_34_nested_dictionary.py` | Nested Dictionary |
| 35 | `task_35_create_tuple.py` | Create Tuple – Coordinates |
| 36 | `task_36_set_intersection.py` | Set Intersection – Common Skills |
| 37 | `task_37_multiple_instances.py` | Multiple Class Instances |
| 38 | `task_38_method_chaining.py` | Method Chaining |
| 39 | `task_39_polymorphism.py` | Polymorphism |
| 40 | `task_40_class_methods.py` | Class Methods (`@classmethod`) |
| 41 | `task_41_employee_management.py` | Employee Management System (JSON) |
| 42 | `task_42_data_analysis_pipeline.py` | Data Analysis – Mean & Median |
| 43 | `task_43_configuration_manager.py` | Configuration Manager (INI) |
| 44 | `task_44_csv_data_processor.py` | CSV Data Processor |
| 45 | `task_45_expense_tracker.py` | Expense Tracker (CSV) |
| 46 | `task_46_api_response_handler.py` | API Response Handler (Weather) |
| 47 | `task_47_calculator.py` | Complete Calculator |
| 48 | `task_48_shopping_cart.py` | Shopping Cart with GST |
| 49 | `task_49_temperature_converter.py` | Temperature Converter |
| 50 | `task_50_backup_utility.py` | Backup Utility |
| 51 | `task_51_url_shortener.py` | URL Shortener (Hashing) |
| 52 | `task_52_gradebook_system.py` | Gradebook System (GPA) |
| 53 | `task_53_task_scheduler.py` | Task Scheduler (Dates) |
| 54 | `task_54_inventory_manager.py` | Inventory Manager |
| 55 | `task_55_budget_planner.py` | Budget Planner (Matplotlib) |

---

## Technologies Used

- Python 3, Jupyter Notebook, VS Code
- MySQL / ANSI SQL
- Libraries: `json`, `csv`, `statistics`, `configparser`, `datetime`, `math`, `requests`, `matplotlib`, `hashlib`, `shutil`

---

## How to Run

```bash
# Clone the repository
git clone https://github.com/<your-username>/Digital-Nurture-Python.git
cd Digital-Nurture-Python

# Run any Python task
python python/task_01_to_30/task_01_hello_world.py

# For SQL tasks – import schema first, then run solutions
mysql -u root -p < mysql/schema.sql
mysql -u root -p your_db < mysql/solutions.sql
```

---

## Author

**Aadithya R**  
B.Tech – Artificial Intelligence and Machine Learning  
Saveetha Engineering College
