#task 31
def display_shopping_cart(cart_items):
    if not isinstance(cart_items, list) or len(cart_items) == 0:
        print("Error: The shopping cart must be a non-empty list.")
        return

    print("Shopping Cart Contents:")
    for item in cart_items:
        print(f"- Item Value: {item}")


shopping_cart = [100, 250, 75]
display_shopping_cart(shopping_cart)
