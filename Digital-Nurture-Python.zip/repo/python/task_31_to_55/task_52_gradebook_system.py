# task 52
import json

students = {}

def add_grade(name, grade):
    if 0 <= grade <= 100:
        students.setdefault(name, []).append(grade)

def calculate_gpa(grades):
    return sum(grades) / len(grades)

add_grade("Aadithya", 90)
add_grade("Aadithya", 85)

with open("grades.json", "w") as file:
    json.dump(students, file)

for name, grades in students.items():
    print(name, "GPA:", calculate_gpa(grades))

class_average = sum(
    calculate_gpa(g) for g in students.values()
) / len(students)

print("Class Average:", class_average)
