# task 44
import csv

def process_csv():

    employees = []

    with open("C:\CTS\employees.csv", "r") as file:

        reader = csv.DictReader(file)

        for row in reader:
            row["salary"] = int(row["salary"])
            employees.append(row)

    high_salary = [emp for emp in employees if emp["salary"] > 50000]

    average_salary = sum(emp["salary"] for emp in employees) / len(employees)

    print("Employees with salary > 50000")
    
    for emp in high_salary:
        print(emp)

    print(f"Average Salary: {average_salary}")


process_csv()
