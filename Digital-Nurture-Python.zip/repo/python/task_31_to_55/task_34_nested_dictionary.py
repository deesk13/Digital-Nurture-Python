#task 34
def get_salary(data, department, employee):

    if department not in data:
        print("Invalid department")
        return

    if employee not in data[department]:
        print("Employee not found")
        return

    print(f"Salary of {employee}: {data[department][employee]}")


employees = {
    "HR": {
        "Arun": 50000,
        "Priya": 60000
    },
    "IT": {
        "Rahul": 75000,
        "Sneha": 80000
    }
}

get_salary(employees, "IT", "Rahul")
