#task 41
import json


class Employee:
    def __init__(self, emp_id, name, role):
        self.emp_id = emp_id
        self.name = name
        self.role = role

    def __str__(self):
        return f"ID: {self.emp_id} | Name: {self.name} | Role: {self.role}"


def save_employees(employee_dict, filename="emps.json"):
    serializable_dict = {
        emp_id: {"name": emp.name, "role": emp.role}
        for emp_id, emp in employee_dict.items()
    }
    with open(filename, "w") as file:
        json.dump(serializable_dict, file, indent=4)


def load_employees(filename="emps.json"):
    try:
        with open(filename, "r") as file:
            data = json.load(file)
            return {
                emp_id: Employee(emp_id, info["name"], info["role"])
                for emp_id, info in data.items()
            }
    except FileNotFoundError:
        return {}


employee_roster = {
    "101": Employee("101", "Alice", "Developer"),
    "102": Employee("102", "Bob", "Manager"),
}

save_employees(employee_roster)

loaded_roster = load_employees()

for employee in loaded_roster.values():
    print(employee)
