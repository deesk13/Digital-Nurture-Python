# task 53
from datetime import datetime

class Task:
    def __init__(self, name, due_date, priority):
        self.name = name
        self.due_date = datetime.strptime(due_date, "%Y-%m-%d")
        self.priority = priority

tasks = [
    Task("Project", "2026-06-10", 1),
    Task("Assignment", "2026-05-20", 2)
]

tasks.sort(key=lambda x: x.due_date)

today = datetime.now()

print("Task Schedule")

for task in tasks:
    status = "Overdue" if task.due_date < today else "Pending"

    print(task.name, task.due_date.date(), status)
