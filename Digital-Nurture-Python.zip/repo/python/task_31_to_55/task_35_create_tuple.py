#task 35
def process_coordinates(coords):
    if not isinstance(coords, tuple) or len(coords) != 2:
        print("Error: Input must be a tuple containing exactly 2 elements (X, Y).")
        return None

    if not all(isinstance(val, (int, float)) for val in coords):
        print("Error: Coordinate values must be numbers.")
        return None

    x, y = coords
    print(f"Fixed Coordinates -> X: {x}, Y: {y}")
    return coords


location_coords = (13.0827, 80.2707)
process_coordinates(location_coords)
