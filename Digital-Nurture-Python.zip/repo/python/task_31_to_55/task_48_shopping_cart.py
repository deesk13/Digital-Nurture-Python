# task 48 
class CartItem:
    def __init__(self, name, price, quantity):
        self.name = name
        self.price = price
        self.quantity = quantity

class ShoppingCart:
    def __init__(self):
        self.items = []

    def add_item(self, item):
        self.items.append(item)

    def calculate_total(self):
        total = sum(item.price * item.quantity for item in self.items)
        gst = total * 0.18
        return total + gst

    def print_receipt(self):
        for item in self.items:
            print(item.name, item.quantity, item.price)

        print("Final Total:", self.calculate_total())

cart = ShoppingCart()

cart.add_item(CartItem("Laptop", 50000, 1))
cart.add_item(CartItem("Mouse", 500, 2))

cart.print_receipt()
