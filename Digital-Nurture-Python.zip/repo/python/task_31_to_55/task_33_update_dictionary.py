#task 33
def merge_employee_details(base_details, new_details):
    if not isinstance(base_details, dict) or not isinstance(new_details, dict):
        print("Error: Both inputs must be dictionaries.")
        return None

    base_details.update(new_details)
    print("Updated Employee Data:", base_details)
    return base_details


employee_base = {"id": 101, "name": "Alice", "role": "Developer"}
employee_update = {"role": "Senior Developer", "department": "Engineering"}

merge_employee_details(employee_base, employee_update)
