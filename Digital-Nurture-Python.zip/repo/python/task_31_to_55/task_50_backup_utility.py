# task 50
import shutil
import os

def backup_files(files, backup_folder):

    copied_files = set()

    try:

        if not os.path.exists(backup_folder):
            os.mkdir(backup_folder)

        log_file = open("backup.log", "a")

        for file in files:

            if file in copied_files:
                log_file.write(f"Skipped duplicate: {file}\n")
                continue

            shutil.copy(file, backup_folder)

            copied_files.add(file)

            log_file.write(f"Copied: {file}\n")

        log_file.close()

        print("Backup completed")

    except FileNotFoundError:
        print("File not found")

    except PermissionError:
        print("Permission denied")


file_list = ["C:\CTS\sales.txt", "C:\CTS\employees.csv", "C:\CTS\expenses.csv"]

backup_files(file_list, "backup")

