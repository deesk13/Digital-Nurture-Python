#task 39
class Employee:
    def work(self):
        print("Employee is performing general duties.")


class Developer(Employee):
    def work(self):
        print("Developer is writing and debugging code.")


class Manager(Employee):
    def work(self):
        print("Manager is organizing meetings and planning timelines.")


employees = [Employee(), Developer(), Manager()]

for emp in employees:
    emp.work()
