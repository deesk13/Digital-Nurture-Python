import csv
from datetime import datetime


def analyze_expenses(file_path):
    current_date = datetime.now()
    current_year = current_date.year
    current_month = current_date.month

    category_totals = {}

    try:
        with open(file_path, "r") as file:
            reader = csv.DictReader(file)

            for row in reader:
                try:
                    expense_date = datetime.strptime(
                        row["date"].strip(), "%Y-%m-%d"
                    )
                except ValueError:
                    continue

                if (
                    expense_date.year == current_year
                    and expense_date.month == current_month
                ):
                    category = row["category"].strip()
                    try:
                        amount = float(row["amount"].strip())
                    except ValueError:
                        continue

                    category_totals[category] = (
                        category_totals.get(category, 0.0) + amount
                    )

    except FileNotFoundError:
        print(f"Error: The file '{file_path}' was not found.")
        return None

    print(
        f"--- Expense Summary for {current_date.strftime('%B %Y')} ---"
    )
    for category, total in category_totals.items():
        print(f"{category}: ${total:.2f}")

    return category_totals


with open("C:\CTS\expenses.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["date", "amount", "category"])
    writer.writerow(["2026-05-15", "45.50", "Food"])
    writer.writerow(["2026-05-20", "12.00", "Transport"])
    writer.writerow(["2026-05-25", "120.00", "Food"])
    writer.writerow(["2026-04-10", "85.00", "Utilities"])

analyze_expenses("C:\CTS\expenses.csv")
