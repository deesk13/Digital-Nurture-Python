# task 49
from tabulate import tabulate

class Converter:
    def c_to_f(self, c):
        return (c * 9/5) + 32

    def f_to_c(self, f):
        return (f - 32) * 5/9

converter = Converter()

celsius = float(input("Enter Celsius: "))

fahrenheit = converter.c_to_f(celsius)

table = [["Celsius", celsius], ["Fahrenheit", round(fahrenheit, 2)]]

print(tabulate(table, headers=["Type", "Value"]))
