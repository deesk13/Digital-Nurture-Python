#task 37
class Employee:
    def __init__(self, name, role):
        self.name = name
        self.role = role

    def display_info(self):
        print(f"Employee Name: {self.name} | Role: {self.role}")


emp1 = Employee("Alice", "Software Engineer")
emp2 = Employee("Bob", "Product Manager")
emp3 = Employee("Charlie", "Data Analyst")

emp1.display_info()
emp2.display_info()
emp3.display_info()
