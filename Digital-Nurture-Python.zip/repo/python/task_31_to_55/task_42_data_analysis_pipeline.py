#task 42
import statistics

def analyze_sales():

    try:
        file = open("C:\CTS\sales.txt", "r")

        sales = []

        for line in file:
            sales.append(float(line.strip()))

        file.close()

        mean_value = statistics.mean(sales)
        median_value = statistics.median(sales)

        print("Sales Statistics")
        print(f"Mean: {mean_value}")
        print(f"Median: {median_value}")

    except FileNotFoundError:
        print("File not found")

    except ValueError:
        print("Invalid data in file")


analyze_sales()
