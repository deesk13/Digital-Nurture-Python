-- =============================================================
-- ANSI SQL Using MySQL – 25 SQL Practice Questions
-- Event Management Database
-- =============================================================

-- Task 1: User Upcoming Events
-- Show all upcoming events a user is registered for in their city, sorted by date.
SELECT e.title, e.city, e.start_date
FROM events e
JOIN registrations r ON e.event_id = r.event_id
JOIN users u ON r.user_id = u.user_id
WHERE u.user_id = 1
  AND e.status = 'upcoming'
  AND e.city = u.city
ORDER BY e.start_date;

-- Task 2: Top Rated Events
-- Identify events with the highest average rating (min 10 feedback submissions).
SELECT e.title, ROUND(AVG(f.rating), 2) AS avg_rating, COUNT(f.feedback_id) AS total_feedback
FROM events e
JOIN feedback f ON e.event_id = f.event_id
GROUP BY e.event_id, e.title
HAVING COUNT(f.feedback_id) >= 10
ORDER BY avg_rating DESC;

-- Task 3: Inactive Users
-- Find users who have never registered for any event.
SELECT u.user_id, u.name, u.email
FROM users u
LEFT JOIN registrations r ON u.user_id = r.user_id
WHERE r.registration_id IS NULL;

-- Task 4: Peak Session Hours
-- Find the hour of the day when the most sessions are scheduled.
SELECT HOUR(start_time) AS session_hour, COUNT(*) AS session_count
FROM sessions
GROUP BY HOUR(start_time)
ORDER BY session_count DESC
LIMIT 1;

-- Task 5: Most Active Cities
-- Find the top 5 cities with the most event registrations.
SELECT e.city, COUNT(r.registration_id) AS total_registrations
FROM events e
JOIN registrations r ON e.event_id = r.event_id
GROUP BY e.city
ORDER BY total_registrations DESC
LIMIT 5;

-- Task 6: Event Resource Summary
-- Show total and available resources for each event.
SELECT e.title,
       COUNT(res.resource_id) AS total_resources,
       SUM(CASE WHEN res.is_available THEN 1 ELSE 0 END) AS available_resources
FROM events e
LEFT JOIN resources res ON e.event_id = res.event_id
GROUP BY e.event_id, e.title;

-- Task 7: Low Feedback Alerts
-- List events that have received fewer than 5 feedback submissions.
SELECT e.title, COUNT(f.feedback_id) AS feedback_count
FROM events e
LEFT JOIN feedback f ON e.event_id = f.event_id
GROUP BY e.event_id, e.title
HAVING COUNT(f.feedback_id) < 5
ORDER BY feedback_count;

-- Task 8: Sessions per Upcoming Event
-- Count the number of sessions scheduled for each upcoming event.
SELECT e.title, COUNT(s.session_id) AS session_count
FROM events e
LEFT JOIN sessions s ON e.event_id = s.event_id
WHERE e.status = 'upcoming'
GROUP BY e.event_id, e.title
ORDER BY session_count DESC;

-- Task 9: Organizer Event Summary
-- Show how many events each organizer has hosted and average rating received.
SELECT u.name AS organizer,
       COUNT(DISTINCT e.event_id) AS total_events,
       ROUND(AVG(f.rating), 2) AS avg_rating
FROM users u
JOIN events e ON u.user_id = e.organizer_id
LEFT JOIN feedback f ON e.event_id = f.event_id
GROUP BY u.user_id, u.name
ORDER BY total_events DESC;

-- Task 10: Feedback Gap
-- Find events that are completed but have received no feedback.
SELECT e.event_id, e.title, e.end_date
FROM events e
LEFT JOIN feedback f ON e.event_id = f.event_id
WHERE e.status = 'completed'
  AND f.feedback_id IS NULL;

-- Task 11: Daily New User Count
-- Show the count of new users registered each day over the last 30 days.
SELECT DATE(registered_at) AS registration_date, COUNT(*) AS new_users
FROM users
WHERE registered_at >= CURDATE() - INTERVAL 30 DAY
GROUP BY DATE(registered_at)
ORDER BY registration_date;

-- Task 12: Event with Maximum Sessions
-- Find the event that has the highest number of sessions.
SELECT e.title, COUNT(s.session_id) AS session_count
FROM events e
JOIN sessions s ON e.event_id = s.event_id
GROUP BY e.event_id, e.title
ORDER BY session_count DESC
LIMIT 1;

-- Task 13: Average Rating per City
-- Calculate the average feedback rating for events held in each city.
SELECT e.city, ROUND(AVG(f.rating), 2) AS avg_rating
FROM events e
JOIN feedback f ON e.event_id = f.event_id
GROUP BY e.city
ORDER BY avg_rating DESC;

-- Task 14: Most Registered Events
-- List the top 10 events by number of registrations.
SELECT e.title, COUNT(r.registration_id) AS registration_count
FROM events e
JOIN registrations r ON e.event_id = r.event_id
GROUP BY e.event_id, e.title
ORDER BY registration_count DESC
LIMIT 10;

-- Task 15: Event Session Time Conflict
-- Identify sessions within the same event that overlap in time.
SELECT a.event_id, a.title AS session_a, b.title AS session_b
FROM sessions a
JOIN sessions b ON a.event_id = b.event_id
  AND a.session_id < b.session_id
  AND a.start_time < b.end_time
  AND b.start_time < a.end_time;

-- Task 16: Unregistered Active Users
-- Find active users who have not registered for any upcoming event.
SELECT u.user_id, u.name, u.email
FROM users u
WHERE u.is_active = TRUE
  AND u.user_id NOT IN (
      SELECT r.user_id
      FROM registrations r
      JOIN events e ON r.event_id = e.event_id
      WHERE e.status = 'upcoming'
  );

-- Task 17: Multi-Session Speakers
-- Find speakers who are scheduled for more than one session.
SELECT speaker, COUNT(*) AS session_count
FROM sessions
WHERE speaker IS NOT NULL
GROUP BY speaker
HAVING COUNT(*) > 1
ORDER BY session_count DESC;

-- Task 18: Resource Availability Check
-- List events where all resources are marked as unavailable.
SELECT e.title
FROM events e
JOIN resources res ON e.event_id = res.event_id
GROUP BY e.event_id, e.title
HAVING SUM(CASE WHEN res.is_available THEN 1 ELSE 0 END) = 0;

-- Task 19: Completed Events with Feedback Summary
-- Show completed events with total feedback count and average rating.
SELECT e.title,
       e.end_date,
       COUNT(f.feedback_id) AS feedback_count,
       ROUND(AVG(f.rating), 2) AS avg_rating
FROM events e
LEFT JOIN feedback f ON e.event_id = f.event_id
WHERE e.status = 'completed'
GROUP BY e.event_id, e.title, e.end_date
ORDER BY e.end_date DESC;

-- Task 20: User Engagement Index
-- Rank users by total number of events registered.
SELECT u.name,
       COUNT(r.registration_id) AS events_registered,
       RANK() OVER (ORDER BY COUNT(r.registration_id) DESC) AS engagement_rank
FROM users u
LEFT JOIN registrations r ON u.user_id = r.user_id
GROUP BY u.user_id, u.name
ORDER BY engagement_rank;

-- Task 21: Top Feedback Providers
-- Find the top 5 users who have submitted the most feedback.
SELECT u.name, COUNT(f.feedback_id) AS feedback_count
FROM users u
JOIN feedback f ON u.user_id = f.user_id
GROUP BY u.user_id, u.name
ORDER BY feedback_count DESC
LIMIT 5;

-- Task 22: Duplicate Registrations Check
-- Detect any users who have registered for the same event more than once.
SELECT user_id, event_id, COUNT(*) AS registration_count
FROM registrations
GROUP BY user_id, event_id
HAVING COUNT(*) > 1;

-- Task 23: Registration Trends
-- Show month-wise registration count over the past 12 months.
SELECT DATE_FORMAT(registered_at, '%Y-%m') AS month,
       COUNT(*) AS registration_count
FROM registrations
WHERE registered_at >= CURDATE() - INTERVAL 12 MONTH
GROUP BY DATE_FORMAT(registered_at, '%Y-%m')
ORDER BY month;

-- Task 24: Average Session Duration per Event
-- Compute the average session duration (in minutes) for each event.
SELECT e.title,
       ROUND(AVG(TIMESTAMPDIFF(MINUTE, s.start_time, s.end_time)), 2) AS avg_duration_minutes
FROM events e
JOIN sessions s ON e.event_id = s.event_id
GROUP BY e.event_id, e.title
ORDER BY avg_duration_minutes DESC;

-- Task 25: Events Without Sessions
-- List all events that have no sessions scheduled.
SELECT e.event_id, e.title, e.start_date
FROM events e
LEFT JOIN sessions s ON e.event_id = s.event_id
WHERE s.session_id IS NULL
ORDER BY e.start_date;
